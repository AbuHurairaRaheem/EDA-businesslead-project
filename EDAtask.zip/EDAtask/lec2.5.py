
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# ==============================================================================
# Step 1: Load the Data
# ==============================================================================

# Requirement 1 - Load and inspect the dataset
df = pd.read_csv("business_leads.csv")

print(df.head(25))
print()

df.info()
print()

print(df.describe().round(1))
print()

print(df.shape)


# ==============================================================================
# Step 2: Understand the Data
# ==============================================================================

numeric_columns = [
    "Contact Method Count",
    "Lead Completeness Pct",
    "Notes Length"
]

categorical_columns = [
    "Business Name",
    "Category",
    "City",
    "Country",
    "Readiness",
    "WhatsApp Likelihood",
    "Phone Available",
    "WhatsApp Available",
    "Source Type"
]

id_columns = ["Lead ID"]

date_columns = []


print("Numeric Columns:", numeric_columns)
print()
print("Categorical Columns:", categorical_columns)
print()
print("ID Columns:", id_columns)
print()
print("Date Columns:", date_columns)


# Dataset Overview:
# This dataset contains information about business leads and their
# contact availability. It contains 120 unique lead records.
# It includes categories, countries, readiness levels, contact methods,
# and lead completeness information.
# It contains both real public leads and synthetic practice leads.


# Questions for EDA:
# 1. Does Contact Method Count differ across Readiness levels?
# 2. Which countries have more Hot, Warm and Cold leads?
# 3. Is there a relationship between Lead Completeness Pct and Notes Length?


# ==============================================================================
# Step 3: Clean, Transform & Explore
# ==============================================================================


# ------------------------------------------------------------------------------
# Handle Missing Values
# ------------------------------------------------------------------------------

# Requirement 2 - Find and handle missing values

print("\nMissing values before cleaning:")
print(df.isna().sum())


# Show rows that contain missing values
missing_rows = df[df.isna().any(axis=1)]

print("\nRows with missing values:")
print(missing_rows)


# City:
# Fill with "Unknown" because the real city is not known,
# but the rest of the lead information is still useful.
df["City"] = df["City"].fillna("Unknown")


# WhatsApp Likelihood:
# Fill with "Unknown" because the real value is not known,
# and we do not want to remove the whole lead.
df["WhatsApp Likelihood"] = df["WhatsApp Likelihood"].fillna("Unknown")


# Requirement 15 - List comprehension
missing_check = [df[col].isna().sum() for col in df.columns]

print("\nMissing values after cleaning:")
print(dict(zip(df.columns, missing_check)))

print("Total missing values remaining:", sum(missing_check))


# ------------------------------------------------------------------------------
# Fix / Transform Columns & Engineer Features
# ------------------------------------------------------------------------------

# Requirement 3 - Filter using 2 conditions
hot_long_notes = df[
    (df["Readiness"] == "Hot") &
    (df["Notes Length"] > 40)
]

print(
    f"\nHot leads with notes longer than 40 characters: "
    f"{len(hot_long_notes)}"
)


# Requirement 4 - New column using lambda
df["Is_Hot_Lead"] = df["Readiness"].apply(
    lambda x: 1 if x == "Hot" else 0
)


# Requirement 5 - New column using a named function
def categorize_notes(length):
    if length < 30:
        return "Short"
    elif length < 50:
        return "Medium"
    else:
        return "Detailed"


df["Notes_Category"] = df["Notes Length"].apply(categorize_notes)


# Requirement 6 - NumPy operation
df["Completeness_Status"] = np.where(
    df["Lead Completeness Pct"] >= 90,
    "High",
    "Low"
)


# Requirement 7 - Sort by 2 columns
df_sorted = df.sort_values(
    by=["Readiness", "Lead Completeness Pct"],
    ascending=[True, False]
)

print("\nTop 5 rows after sorting:")

print(
    df_sorted[
        ["Business Name", "Readiness", "Lead Completeness Pct"]
    ].head()
)


# Requirement 14 - Merge a small lookup DataFrame
priority_lookup = pd.DataFrame({
    "Readiness": ["Cold", "Warm", "Hot"],
    "Priority_Level": [
        "Low Priority",
        "Medium Priority",
        "High Priority"
    ]
})

df = pd.merge(
    df,
    priority_lookup,
    on="Readiness",
    how="left"
)

print("\nPriority lookup merged successfully.")


# ------------------------------------------------------------------------------
# Look at Distributions
# ------------------------------------------------------------------------------

# Requirement 13 - Matplotlib chart

# Distribution 1 - Notes Length
plt.figure(figsize=(7, 4))

plt.hist(
    df["Notes Length"],
    bins=8,
    color="skyblue",
    edgecolor="black"
)

plt.title("Distribution of Notes Length")
plt.xlabel("Notes Length")
plt.ylabel("Frequency")

# Distribution 1 - Notes Length
plt.tight_layout()
plt.savefig("notes_length_distribution.png")
plt.show()
# Interpretation:
# Notes Length is right-skewed because most notes are shorter,
# while a few leads have very long notes.


# Distribution 2 - Lead Completeness
plt.figure(figsize=(7, 4))

plt.hist(
    df["Lead Completeness Pct"],
    bins=8,
    color="orange",
    edgecolor="black"
)

plt.title("Distribution of Lead Completeness")
plt.xlabel("Lead Completeness Pct")
plt.ylabel("Frequency")
# Distribution 2 - Lead Completeness
plt.tight_layout()
plt.savefig("lead_completeness_distribution.png")
plt.show()

# Interpretation:
# Most leads have high completeness percentages.
# The distribution is concentrated near 100%.


# ------------------------------------------------------------------------------
# Find Outliers
# ------------------------------------------------------------------------------

# Requirement 12 - Boxplot
plt.figure(figsize=(7, 4))

sns.boxplot(
    data=df,
    x="Readiness",
    y="Notes Length",
    order=["Cold", "Warm", "Hot"],
    color="skyblue"
)

plt.title("Notes Length by Readiness")
plt.xlabel("Readiness")
plt.ylabel("Notes Length")

# Boxplot
plt.tight_layout()
plt.savefig("notes_length_boxplot.png")
plt.show()

# Find Notes Length outliers using IQR
q1 = df["Notes Length"].quantile(0.25)
q3 = df["Notes Length"].quantile(0.75)

iqr = q3 - q1

upper_limit = q3 + (1.5 * iqr)

outliers = df[
    df["Notes Length"] > upper_limit
]

print("\nNotes Length outliers:")

print(
    outliers[
        ["Business Name", "Notes Length", "Readiness"]
    ]
)

# Interpretation:
# A few leads have much longer notes than the majority,
# which makes them visible as outliers.


# ------------------------------------------------------------------------------
# Check Correlations
# ------------------------------------------------------------------------------

# Requirement 11 - Correlation heatmap

numeric_df = df[
    [
        "Contact Method Count",
        "Lead Completeness Pct",
        "Notes Length"
    ]
]

corr_matrix = numeric_df.corr()


plt.figure(figsize=(6, 4))

sns.heatmap(
    corr_matrix,
    annot=True,
    cmap="Blues",
    fmt=".2f",
    vmin=-1,
    vmax=1
)

plt.title("Correlation of Numeric Columns")

# Correlation Heatmap
plt.tight_layout()
plt.savefig("correlation_heatmap.png")
plt.show()
# Interpretation:
# Contact Method Count and Lead Completeness have a strong relationship.
# Notes Length has only a weak relationship with the other numeric columns.


# ------------------------------------------------------------------------------
# Group and Compare
# ------------------------------------------------------------------------------

# Requirement 8 - Groupby with one aggregate
avg_contact_by_readiness = (
    df.groupby("Readiness")["Contact Method Count"].mean()
)

print("\nAverage Contact Method Count by Readiness:")
print(avg_contact_by_readiness.round(2))


# Requirement 9 - Groupby with multiple statistics
multi_stats = (
    df.groupby("Readiness")["Lead Completeness Pct"]
    .agg(["mean", "min", "max", "count"])
)

print("\nLead Completeness Statistics by Readiness:")
print(multi_stats.round(2))


# Group Country and Readiness
country_readiness = (
    df.groupby(["Country", "Readiness"])
    .size()
    .unstack(fill_value=0)
)


# Requirement 10 - Put grouped result in logical order
country_readiness = country_readiness.reindex(
    columns=["Cold", "Warm", "Hot"],
    fill_value=0
)


# ==============================================================================
# Step 4: Visualize Findings
# ==============================================================================

country_readiness.plot(
    kind="bar",
    figsize=(9, 4.5),
    edgecolor="black"
)

plt.title("Lead Readiness by Country")
plt.xlabel("Country")
plt.ylabel("Number of Leads")
plt.legend(title="Readiness")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("lead_readiness_by_country.png")
plt.show()
# Interpretation:
# USA has the highest number of Hot and Warm leads.
# Australia has the highest number of Cold leads.


# ==============================================================================
# Final Conclusions
# ==============================================================================

print("\n" + "=" * 50)
print("FINAL CONCLUSIONS")
print("=" * 50)


print("""
1. Does Contact Method Count differ across Readiness levels?

Yes. Hot leads have the highest average Contact Method Count
at about 1.66, followed by Warm at 1.38 and Cold at 1.27.


2. Which countries have more Hot, Warm and Cold leads?

USA has the most Hot leads (14) and Warm leads (11).
Australia has the most Cold leads (4).


3. Is there a relationship between Lead Completeness Pct
   and Notes Length?

There is no strong relationship.
Their correlation is about 0.10, which shows only a very weak
positive relationship.


Limitation:
This dataset contains both real public leads and synthetic practice
leads, so these findings describe this dataset only and should not
be treated as general market conclusions.
""")
